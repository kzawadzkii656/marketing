import {setupUpdates} from './updates.mjs';
import {requireLogin,accountDatabase,loginIdentity,signOut} from './auth.mjs';
import {GoogleCalendar} from './google-calendar.mjs';
import * as pdfjs from './vendor/pdf.mjs';
import {linesFromItems,parsePages,eventsFor} from './parser.mjs';
import {groups,exclusion} from './profile.mjs';
import {documentPeriod,documentForDate} from './documents.mjs';
pdfjs.GlobalWorkerOptions.workerSrc=new URL('./vendor/pdf.worker.mjs',import.meta.url).href;
const $=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const localDate=()=>{const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`};
let previewObserver=null,reviewDocumentId=null;
let state={docs:[],active:null,profile:{city:'',facts:{}}},tab='today',mode='approved',date=localDate(),busy=false,pdfCache=null;
await requireLogin();
const db=await new Promise((resolve,reject)=>{const r=indexedDB.open(accountDatabase(loginIdentity),1);r.onupgradeneeded=()=>r.result.createObjectStore('data');r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)}).catch(e=>{ $('#app').innerHTML='<p>Nie można otworzyć pamięci telefonu. Otwórz aplikację w zwykłym oknie Safari i sprawdź wolne miejsce.</p>';throw e});
function get(key){return new Promise((resolve,reject)=>{const r=db.transaction('data').objectStore('data').get(key);r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)})}
async function put(key,value){pendingWrites++;try{return await new Promise((resolve,reject)=>{const tx=db.transaction('data','readwrite');tx.objectStore('data').put(value,key);tx.oncomplete=()=>resolve();tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error)})}finally{pendingWrites--}}
let googleCalendar,pendingWrites=0,updateJobs=0;
async function save(){await put('state',state);googleCalendar?.schedule()}
const stored=await get('state');if(stored)state=stored;
if(state.profile){
 const hadTrackingData='storeNumber' in state.profile||'lastReportedDay' in state.profile;
 delete state.profile.storeNumber;
 delete state.profile.lastReportedDay;
 if(hadTrackingData)await save();
}
googleCalendar=new GoogleCalendar({get,put,getState:()=>state,onStatus:updateCalendarStatus});
await googleCalendar.load();
const active=()=>tab==='plan'&&reviewDocumentId?state.docs.find(d=>d.id===reviewDocumentId):documentForDate(state.docs,date);
function reviewImported(doc){const period=documentPeriod(doc);if(period){if(date<period.start||date>period.end)date=period.start;reviewDocumentId=null}else reviewDocumentId=doc.id;}
function toast(s){$('#toast').textContent=s;$('#toast').style.display='block';clearTimeout(toast.timer);toast.timer=setTimeout(()=>$('#toast').style.display='none',5000)}
const titles={put:'WYSTAW',remove:'ZDEJMIJ',keep:'POZOSTAJE',print:'WYDRUKUJ'};
function badge(a){return `<span class="pill ${a==='remove'?'remove':a==='keep'?'keep':'put'}">${titles[a]}</span>`}
function documentInfo(d){return d?`<p class="hint">Materiały: ${esc(d.name)}${documentPeriod(d)?'':' • nie rozpoznano okresu obowiązywania'}</p>`:''}
function dateControl(){return `<label for="day">Dzień</label><input id="day" type="date" value="${date}">`}
function render(){ $('#store-name').textContent='Twój plan ekspozycji';document.querySelectorAll('nav button').forEach(b=>{b.classList.toggle('active',b.dataset.tab===tab);b.disabled=busy}); const d=active();
 if(tab==='settings')renderSettings();else if(tab==='import')renderImport();else if(tab==='plan')renderPlan(d);else renderToday(d);
 if(googleCalendar.enabled){const p=document.createElement('p');p.className='hint';p.dataset.calendarStatus='';p.textContent=googleCalendar.status;$('#app').prepend(p)}
 $('#day')?.addEventListener('change',e=>{if(e.target.value){date=e.target.value;reviewDocumentId=null;render()}});}
function previewMarkup(t){return t.page?`<div class="preview-frame" data-preview="${esc(t.id)}"><span>Ładowanie podglądu…</span><canvas></canvas></div>`:''}
function taskCard(t,d){return `<article class="card ${d.completed?.[t.eventKey]?'done':''}">${badge(t.eventAction)}<div class="task-title" style="margin-top:12px"><input type="checkbox" aria-label="Wykonano: ${esc(t.title)}" data-complete="${esc(t.eventKey)}" ${d.completed?.[t.eventKey]?'checked':''}><h3>${esc(t.title)}</h3></div><div class="task-meta">${t.page?'PDF, str. '+t.page:'Zadanie ręczne'}${t.indices.length?' • '+esc(t.indices.slice(0,3).join(', ')):''}${t.notes?`<p>${esc(t.notes)}</p>`:''}</div>${previewMarkup(t)}<div class="task-actions">${t.page?`<button data-crop="${esc(t.id)}">Powiększ materiał</button><button data-source="${t.page}">Cała strona PDF</button>`:''}</div></article>`}
function bindTasks(d){initPreviews(d);document.querySelectorAll('[data-crop]').forEach(b=>b.onclick=()=>showCrop(d,d.tasks.find(t=>t.id===b.dataset.crop)));document.querySelectorAll('[data-source]').forEach(b=>b.onclick=()=>showPage(d,Number(b.dataset.source)));document.querySelectorAll('[data-complete]').forEach(b=>b.onchange=async()=>{d.completed??={};d.completed[b.dataset.complete]=b.checked;await save();render()})}
function renderToday(d){const tasks=d?eventsFor(d.tasks.filter(t=>!exclusion(t,state.profile)),date):[];const finished=tasks.filter(t=>d.completed?.[t.eventKey]).length;const remains=d?.tasks.filter(t=>t.status==='approved'&&!exclusion(t,state.profile)&&['put','keep'].includes(t.action)&&(!t.start||t.start<=date)&&(!t.end||t.end>=date))||[];
 $('#app').innerHTML=`<h1>Plan dnia</h1><p class="muted">Wszystko, co trzeba zmienić w ekspozycji.</p>${dateControl()}${documentInfo(d)}${d?`<div class="row between" style="margin-top:20px"><b>${finished} / ${tasks.length} wykonane</b><small>${d.tasks.filter(t=>!!exclusion(t,state.profile)).length} poza profilem</small></div><div class="progress"><span style="width:${tasks.length?finished/tasks.length*100:0}%"></span></div>`:''}${tasks.length?tasks.map(t=>taskCard(t,d)).join(''):`<div class="card empty"><b>${d?'Brak zatwierdzonych zadań na ten dzień':state.docs.length?'Brak materiałów na wybrany dzień':'Dodaj pierwszy PDF'}</b><p class="muted">${d?'Zmień datę lub sprawdź propozycje w zakładce Plan.':state.docs.length?'Wybierz inną datę lub zaimportuj PDF obejmujący ten dzień.':'Przygotuj swój pierwszy plan marketingowy.'}</p><button id="go" class="primary">${d?'Przejdź do planu':'Importuj materiały'}</button></div>`}${remains.length?`<h2>W ekspozycji · ${remains.length}</h2>${remains.map(t=>`<div class="card">${badge('keep')}<h3>${esc(t.title)}</h3><small>${t.end?'Do '+t.end:'Bez ustalonej daty końca'}</small>${previewMarkup(t)}${t.page?`<button class="wide" data-source="${t.page}">Podgląd PDF</button>`:''}</div>`).join('')}`:''}`;
 $('#go')?.addEventListener('click',()=>{tab=d?'plan':'import';mode='draft';render()});bindTasks(d);}
function editor(t,d){return `<details id="task-${t.id}" class="card"><summary>${badge(t.action)} ${esc(t.title)}<br><small>${t.status==='approved'?'Zatwierdzone':t.status==='skipped'?'Nie dotyczy':'Do sprawdzenia'} • ${t.page?'str. '+t.page:'ręcznie'}</small>${previewMarkup(t)}</summary>${exclusion(t,state.profile)?`<div class="notice">Poza profilem sklepu: ${esc(exclusion(t,state.profile))}</div>`:''}${t.issues.length?`<div class="notice">${t.issues.map(esc).join('<br>')}</div>`:''}<form data-task="${t.id}"><label>Nazwa<input name="title" value="${esc(t.title)}" required maxlength="300"></label><label>Czynność<select name="action">${Object.entries(titles).map(([k,v])=>`<option value="${k}" ${t.action===k?'selected':''}>${v}</option>`).join('')}</select></label><div class="grid"><label>Data czynności / początek<input name="start" type="date" value="${t.start}"></label><label>Ostatni dzień ekspozycji<input name="end" type="date" value="${t.end}"></label></div><p class="hint">Dla „WYSTAW” zdjęcie pojawi się następnego dnia po końcu ekspozycji. Puste pole końca oznacza brak automatycznego zdjęcia. Rozdziel warianty przyciskiem „Duplikuj”.</p><label>Instrukcja dla pracownika<textarea name="notes">${esc(t.notes)}</textarea></label><div class="row"><button class="primary" type="submit">Zapisz zmiany</button><button type="button" data-skip="${t.id}">Nie dotyczy</button><button type="button" data-duplicate="${t.id}">Duplikuj</button></div></form>${t.page?`<button class="wide" data-source="${t.page}">Otwórz stronę ${t.page} PDF</button>`:''}<details><summary>Odczytany tekst źródłowy</summary><div class="source">${esc(t.source)}</div></details></details>`}
function renderPlan(d){$('#app').innerHTML=`<h1>Twój plan</h1><p class="muted">Sprawdź daty i wybierz materiały dla swojego sklepu.</p>${dateControl()}${documentInfo(d)}${!d?'<div class="card empty">Brak materiałów na wybrany dzień. Zmień datę lub dodaj odpowiedni PDF w zakładce Import.</div>':`<div class="notice">Import tworzy propozycje, nie kompletny zweryfikowany harmonogram. Sprawdź wszystkie strony PDF, warianty i daty. Materiały z jednoznacznym wyłączeniem dla Twojego profilu trafiają do zakładki „Poza profilem”.</div><small>${d.pages} stron • ${d.tasks.length} pozycji • ${d.tasks.filter(t=>t.status==='approved'&&!exclusion(t,state.profile)).length} w planie • ${d.tasks.filter(t=>!!exclusion(t,state.profile)).length} poza profilem</small>${d.uncovered.length?`<p class="hint">Strony bez rozpoznanych nagłówków: ${d.uncovered.join(', ')}. Przejrzyj je w oryginale.</p>`:''}<div class="row"><button id="accept-all" class="primary">Akceptuj wszystko (${d.tasks.filter(t=>t.status==='draft').length})</button><button id="manual">+ Dodaj zadanie</button><button id="browse">Przeglądaj cały PDF</button></div><div class="tabs">${[['draft','Do sprawdzenia'],['approved','W planie'],['excluded','Poza profilem'],['all','Wszystkie']].map(([k,v])=>`<button data-mode="${k}" class="${mode===k?'active':''}">${v}</button>`).join('')}</div>${d.tasks.filter(t=>mode==='all'||(mode==='excluded'?!!exclusion(t,state.profile):t.status===mode&&!exclusion(t,state.profile))).map(t=>editor(t,d)).join('')||'<div class="card">Brak pozycji w tej kategorii.</div>'}`}`;
 if(!d)return;bindTasks(d);$('#accept-all').onclick=async()=>{const drafts=d.tasks.filter(t=>t.status==='draft');if(!drafts.length)return toast('Wszystkie zadania są już zaakceptowane.');for(const t of drafts){if(t.action!=='keep'&&!t.start)t.start=d.cycle.start||date;t.status='approved'}await save();mode='approved';render();toast(`Dodano ${drafts.length} zadań do planu. Warianty możesz później pominąć lub poprawić.`)};document.querySelectorAll('[data-mode]').forEach(b=>b.onclick=()=>{mode=b.dataset.mode;render()});$('#manual').onclick=async()=>{d.tasks.unshift({id:crypto.randomUUID(),title:'Nowe zadanie',action:'put',start:date,end:'',notes:'',source:'Dodano ręcznie',indices:[],issues:[],status:'draft',page:0});await save();mode='draft';render();$('details[id^=task]').open=true};$('#browse').onclick=()=>showPage(d,1);
 document.querySelectorAll('[data-task]').forEach(f=>f.onsubmit=async e=>{e.preventDefault();const v=Object.fromEntries(new FormData(f));if(v.action!=='keep'&&!v.start)return toast('Wybierz datę czynności.');if(v.end&&v.start&&v.end<v.start)return toast('Koniec nie może poprzedzać początku.');const t=d.tasks.find(t=>t.id===f.dataset.task);if(t.start!==v.start||t.end!==v.end||t.action!==v.action){delete d.completed?.[t.id+':start'];delete d.completed?.[t.id+':end']}Object.assign(t,v);await save();toast('Zmiany zapisane.');render()});document.querySelectorAll('[data-skip]').forEach(b=>b.onclick=async()=>{d.tasks.find(t=>t.id===b.dataset.skip).status='skipped';await save();render()});document.querySelectorAll('[data-duplicate]').forEach(b=>b.onclick=async()=>{const t=structuredClone(d.tasks.find(t=>t.id===b.dataset.duplicate));t.id=crypto.randomUUID();t.status='draft';t.title+=' — wariant';d.tasks.unshift(t);await save();mode='draft';render();$('#task-'+t.id).open=true});}
function renderImport(){ $('#app').innerHTML=`<h1>Dodaj materiały</h1><p class="muted">PDF zostaje na tym urządzeniu.</p><section class="card"><div class="upload"><h2>Materiały marketingowe</h2><p>Wybierz plik zapisany w telefonie.</p><label class="file-label">Wybierz PDF<input id="pdf-input" type="file" accept="application/pdf,.pdf"></label><p class="hint">Do 30 MB i 150 stron</p></div><p id="import-progress" role="status"></p></section><div class="card"><h3>Jak działa import?</h3><p>Odczytuje tekst i nagłówki, tworzy zadania z podglądem wycinka PDF. Możesz zaakceptować wszystkie naraz, a później poprawić daty i warianty.</p><p class="hint">Obsługuje PDF z warstwą tekstową. Skany bez tekstu wymagają OCR poza aplikacją. Podgląd pokazuje oryginalną stronę — bez odtwarzania grafik przez AI.</p></div><div class="notice">Link do SharePoint nie zastępuje pliku. Pobierz PDF po zalogowaniu i wybierz go tutaj. Osobne samodruki nie są zawarte w podglądzie instrukcji.</div>`;$('#pdf-input').onchange=e=>importPDF(e.target.files[0]);}
async function loadPDF(bytes){return pdfjs.getDocument({data:new Uint8Array(bytes),isEvalSupported:false,wasmUrl:new URL('./vendor/wasm/',import.meta.url).href,standardFontDataUrl:new URL('./vendor/standard_fonts/',import.meta.url).href,cMapUrl:new URL('./vendor/cmaps/',import.meta.url).href,cMapPacked:true}).promise}
async function readTextContent(page){
 const reader=page.streamTextContent().getReader();
 const items=[];
 try{while(true){const {value,done}=await reader.read();if(done)break;items.push(...(value.items||[]));}}
 finally{reader.releaseLock()}
 return items;
}
async function importPDFWork(file){if(!file)return;if(file.size>30*1024*1024)return toast('Plik jest większy niż 30 MB.');busy=true;document.querySelectorAll('nav button').forEach(b=>b.disabled=true);$('#pdf-input').disabled=true;let pdf;try{const bytes=await file.arrayBuffer();const hash=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))).map(n=>n.toString(16).padStart(2,'0')).join('');if(state.docs.some(d=>d.id===hash)){state.active=hash;reviewImported(state.docs.find(d=>d.id===hash));await save();toast('Ten PDF jest już zapisany. Zachowano postęp.');tab='plan';mode='draft';return}pdf=await loadPDF(bytes.slice(0));if(pdf.numPages>150)throw Error('Dokument ma więcej niż 150 stron.');const pages=[];let chars=0;for(let n=1;n<=pdf.numPages;n++){$('#import-progress').textContent=`Odczytywanie strony ${n} z ${pdf.numPages}…`;const p=await pdf.getPage(n),items=await readTextContent(p);const lines=linesFromItems(items);chars+=lines.reduce((s,l)=>s+l.text.length,0);pages.push({page:n,lines});p.cleanup();await new Promise(r=>setTimeout(r,0))}if(chars<150)throw Error('Nie wykryto czytelnego tekstu. To może być skan — potrzebny jest OCR.');const parsed=parsePages(pages);const doc={id:hash,name:file.name,pages:pdf.numPages,...parsed,completed:{},created:new Date().toISOString()};const updated=structuredClone(state);updated.docs.push(doc);updated.active=hash;await new Promise((resolve,reject)=>{const tx=db.transaction('data','readwrite');tx.objectStore('data').put(bytes,'pdf:'+hash);tx.objectStore('data').put(updated,'state');tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error)});state=updated;googleCalendar.schedule();reviewImported(doc);tab='plan';mode='draft';toast(`Odczytano ${pdf.numPages} stron. Sprawdź ${parsed.tasks.length} propozycji.`);}catch(e){toast('Import nieudany: '+e.message)}finally{await pdf?.destroy();busy=false;render()}}

// Crop the original PDF between this heading and the next material heading.
// IDs generated by the parser preserve the source line index even for already imported PDFs.
const previewBounds=new Map();
async function getPdf(d){
 if(pdfCache?.id===d.id)return pdfCache.pdf;
 const bytes=await get('pdf:'+d.id);if(!bytes)throw Error('Brak pliku PDF.');
 const pdf=await loadPDF(bytes);const old=pdfCache;pdfCache={id:d.id,pdf};if(old)old.pdf.destroy().catch(()=>{});previewBounds.clear();return pdf;
}
async function cropBounds(d,t,p){
 const key=d.id+':'+t.page;
 let info=previewBounds.get(key);
 if(!info){const rows=linesFromItems(await readTextContent(p));info={rows,marks:d.tasks.filter(x=>x.page===t.page&&/^p\d+-\d+$/.test(x.id)).map(x=>Number(x.id.split('-')[1])).sort((a,b)=>a-b)};previewBounds.set(key,info)}
 const pos=Number(t.id.match(/^p\d+-(\d+)$/)?.[1]);
 if(!Number.isInteger(pos)||!info.rows[pos])return null;
 const next=info.marks.find(i=>i>pos);
 const h=p.getViewport({scale:1}).height;
 const upper=Math.min(h,info.rows[pos].y+30);
 const lower=next!==undefined?Math.max(0,info.rows[next].y+22):34;
 return {top:Math.max(0,h-upper),height:Math.min(h,Math.max(65,upper-lower))};
}
async function paintCrop(d,t,canvas,scale=1.25){
 const pdf=await getPdf(d),p=await pdf.getPage(t.page),bounds=await cropBounds(d,t,p);
 if(!bounds)throw Error('Brak dokładnego zakresu. Otwórz całą stronę PDF.');
 const viewport=p.getViewport({scale}),full=document.createElement('canvas');full.width=Math.ceil(viewport.width);full.height=Math.ceil(viewport.height);
 try{
  await p.render({canvasContext:full.getContext('2d'),viewport}).promise;
  const sy=Math.floor(bounds.top*scale),sh=Math.min(full.height-sy,Math.ceil(bounds.height*scale));
  if(sh<=0)throw Error('Nieprawidłowy zakres wycinka.');
  canvas.width=full.width;canvas.height=sh;
  canvas.getContext('2d').drawImage(full,0,sy,full.width,sh,0,0,full.width,sh);
 }finally{full.width=0;full.height=0}
}
function initPreviews(d){
 previewObserver?.disconnect();if(!d)return;
 previewObserver=new IntersectionObserver(entries=>{
  for(const entry of entries){if(!entry.isIntersecting)continue;
   const frame=entry.target;previewObserver.unobserve(frame);
   const t=d.tasks.find(x=>x.id===frame.dataset.preview);
   if(!t)continue;
   paintCrop(d,t,frame.querySelector('canvas')).then(()=>{
    if(frame.isConnected){frame.classList.add('ready');frame.querySelector('span').remove()}
   }).catch(()=>{if(frame.isConnected)frame.querySelector('span').textContent='Podgląd niedostępny — otwórz stronę PDF.'});
  }
 },{rootMargin:'250px'});
 document.querySelectorAll('[data-preview]').forEach(el=>previewObserver.observe(el));
}
async function showCrop(d,t){
 if(!t)return;if(!$('#viewer').open)$('#viewer').showModal();
 $('#viewer-title').textContent=t.title;
 const container=$('#pdf-page');container.innerHTML='<p>Wczytywanie wycinka…</p>';
 const canvas=document.createElement('canvas');
 try{await paintCrop(d,t,canvas,1.8);container.innerHTML='';container.append(canvas);
  const button=document.createElement('button');button.textContent=`Cała strona ${t.page}`;button.className='wide';button.onclick=()=>showPage(d,t.page);container.prepend(button)
 }catch(e){container.textContent=e.message;const button=document.createElement('button');button.textContent='Otwórz stronę PDF';button.onclick=()=>showPage(d,t.page);container.append(button)}
}
async function showPage(d,n){const container=$('#pdf-page');if(!$('#viewer').open)$('#viewer').showModal();container.innerHTML='<p>Wczytywanie strony…</p>';try{await getPdf(d);$('#viewer-title').textContent=`PDF • strona ${n} / ${pdfCache.pdf.numPages}`;container.innerHTML='<div class="row" id="page-controls"></div><canvas></canvas>';const controls=$('#page-controls');for(const [label,num] of [['← Poprzednia',n-1],['Następna →',n+1]]){const b=document.createElement('button');b.textContent=label;b.disabled=num<1||num>pdfCache.pdf.numPages;b.onclick=()=>showPage(d,num);controls.append(b)}const p=await pdfCache.pdf.getPage(n);const viewport=p.getViewport({scale:Math.min(2,1100/p.getViewport({scale:1}).width)});const canvas=container.querySelector('canvas');canvas.width=viewport.width;canvas.height=viewport.height;await p.render({canvasContext:canvas.getContext('2d'),viewport}).promise;}catch(e){container.textContent='Nie udało się wyświetlić strony: '+e.message}}
$('#close-viewer').onclick=()=>$('#viewer').close();
function profileControls(){const facts=state.profile.facts||{};return groups.map(g=>`<details class="card profile-group"><summary>${esc(g.name)}</summary><div class="grid">${g.fields.map(([key,label,type,options])=>type==='text'?`<label>${esc(label)}<input name="city" value="${esc(state.profile.city)}" placeholder="np. Warszawa"></label>`:`<label>${esc(label)}<select data-fact="${key}">${options.map(([val,name])=>`<option value="${esc(val)}" ${facts[key]===val?'selected':''}>${esc(name)}</option>`).join('')}</select></label>`).join('')}</div></details>`).join('')}
function renderSettings(){$('#app').innerHTML=`<h1>Twój sklep</h1><p class="muted">Profil i dane zapisane na tym telefonie.</p>${accountSettings()}${calendarSettings()}<form id="profile"><p class="hint">Wybierz znane parametry poniżej. „Nie wiem” pozostawia zadania widoczne.</p>${profileControls()}<div class="card"><p>Po zapisaniu sprawdź zakładkę Plan → Poza profilem. Wyłączenie zadania jest podpowiedzią wynikającą z treści PDF; zadania i odhaczenia zostają zachowane.</p><button class="primary wide">Zapisz profil</button></div></form><section class="card"><h3>Kopia zapasowa</h3><p>Eksport obejmuje PDF-y, profil, zadania i wykonanie. Przechowuj kopię w Plikach. Dane nie synchronizują się między telefonami; usunięcie danych witryny może je skasować.</p><button id="export">Pobierz kopię</button><label class="file-label">Przywróć kopię<input type="file" id="restore" accept=".json,application/json"></label><p class="hint">Przywrócenie dodaje dokumenty i zastępuje dokumenty o tym samym identyfikatorze.</p></section><section class="card"><h3>Aktualizacja aplikacji</h3><p>Nowa wersja jest pobierana w tle podczas korzystania z aplikacji. Gdy będzie gotowa, zobaczysz przyciski „Aktualizuj teraz” i „Później”.</p><button id="check-update">Sprawdź aktualizację</button><p class="hint">Jeśli widzisz starszą wersję aplikacji, otwórz na tym telefonie stronę <a href="./aktualizacja.html">Aktualizacja aplikacji</a>.</p></section><section class="card"><h3>Instalacja na iPhonie</h3><p>Otwórz adres aplikacji w Safari → Udostępnij → Dodaj do ekranu początkowego. Otwórz ikonę i poczekaj na komunikat „Gotowa offline”.</p><p id="offline-info" class="hint">${offlineReady?'Gotowa offline.':'Przy pierwszym uruchomieniu potrzebne jest połączenie z internetem.'}</p></section>${active()?'<button id="delete" class="danger wide">Usuń wybrany dokument i jego zadania</button>':''}`;
 $('#check-update').onclick=()=>window.dispatchEvent(new Event('marketing-check-update'));bindAccountSettings();bindCalendarSettings();
 $('#profile').onsubmit=async e=>{e.preventDefault();const data=Object.fromEntries(new FormData(e.target));const facts={};e.target.querySelectorAll('[data-fact]').forEach(el=>facts[el.dataset.fact]=el.value);const {name,equipment,variant,...retained}=state.profile;state.profile={...retained,...data,facts};await save();toast('Profil zapisany.');render()};$('#export').onclick=exportBackup;$('#restore').onchange=e=>restoreBackup(e.target.files[0]);$('#delete')?.addEventListener('click',async()=>{const d=active();if(!confirm(`Usunąć „${d.name}” i jego postęp?`))return;state.docs=state.docs.filter(x=>x.id!==d.id);state.active=state.docs[0]?.id||null;await save();await new Promise((resolve,reject)=>{const tx=db.transaction('data','readwrite');tx.objectStore('data').delete('pdf:'+d.id);tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error)});render()});}
async function exportBackupWork(){try{const pdfs={};for(const d of state.docs){const bytes=await get('pdf:'+d.id);pdfs[d.id]=await new Promise(resolve=>{const r=new FileReader();r.onload=()=>resolve(r.result.split(',')[1]);r.readAsDataURL(new Blob([bytes]))})}const blob=new Blob([JSON.stringify({format:'marketing-sklepu',version:1,state,pdfs})],{type:'application/json'});const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=`marketing-kopia-${localDate()}.json`;a.click();setTimeout(()=>URL.revokeObjectURL(url),30000);toast('Kopia przygotowana do zapisania.')}catch(e){toast('Nie udało się przygotować kopii: '+e.message)}}
async function restoreBackupWork(file){if(!file)return;try{if(file.size>150*1024*1024)throw Error('Kopia jest większa niż 150 MB.');const b=JSON.parse(await file.text());if(b.format!=='marketing-sklepu'||b.version!==1||!Array.isArray(b.state?.docs)||!b.pdfs)throw Error('Nieprawidłowy format kopii.');for(const d of b.state.docs){if(!/^[a-f0-9]{64}$/.test(d.id)||typeof d.name!=='string'||!Array.isArray(d.tasks)||!Array.isArray(d.uncovered)||typeof b.pdfs[d.id]!=='string')throw Error('Nieprawidłowy dokument w kopii.');for(const t of d.tasks){if(!Number.isInteger(t.page)||t.page<0||t.page>d.pages||typeof t.title!=='string'||typeof t.id!=='string'||!/^[\w-]+$/.test(t.id)||!['put','remove','keep','print'].includes(t.action)||!['draft','approved','skipped'].includes(t.status)||!Array.isArray(t.issues)||!Array.isArray(t.indices)||!/^$|^\d{4}-\d{2}-\d{2}$/.test(t.start)||!/^$|^\d{4}-\d{2}-\d{2}$/.test(t.end))throw Error('Nieprawidłowe zadanie w kopii.')}}if(!confirm('Przywrócić kopię? Dokumenty o tych samych identyfikatorach zostaną zastąpione.'))return;const decoded={};for(const d of b.state.docs){const raw=atob(b.pdfs[d.id]);const bytes=Uint8Array.from(raw,c=>c.charCodeAt(0));if(new TextDecoder().decode(bytes.slice(0,5))!=='%PDF-')throw Error('Nieprawidłowe dane PDF.');decoded[d.id]=bytes.buffer;}const tx=db.transaction('data','readwrite');const st=tx.objectStore('data');const merged=structuredClone(state);for(const d of b.state.docs){st.put(decoded[d.id],'pdf:'+d.id);merged.docs=merged.docs.filter(x=>x.id!==d.id);merged.docs.push(d)}merged.profile=b.state.profile||merged.profile;if(merged.profile){delete merged.profile.storeNumber;delete merged.profile.lastReportedDay}merged.active=merged.docs[0]?.id||null;st.put(merged,'state');await new Promise((resolve,reject)=>{tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error)});state=merged;googleCalendar.schedule();pdfCache=null;reviewDocumentId=null;render();toast('Przywrócono kopię.')}catch(e){toast('Nie można przywrócić kopii: '+e.message)}}
let offlineReady=false;
document.querySelectorAll('nav button').forEach(b=>b.onclick=()=>{if(!busy){tab=b.dataset.tab;if(tab!=='plan')reviewDocumentId=null;render()}});
function connection(){ $('#connection').textContent=navigator.onLine?(offlineReady?'Gotowa offline':'Lokalnie'):'Offline'}
addEventListener('online',connection);addEventListener('offline',connection);addEventListener('unhandledrejection',e=>{console.error(e.reason);toast('Nie udało się zapisać lub odczytać danych. Sprawdź wolne miejsce i zrób kopię.');});render();
setupUpdates({isBusy:()=>busy||pendingWrites>0||updateJobs>0||googleCalendar.working,onReady:()=>{offlineReady=true;connection();const info=$('#offline-info');if(info)info.textContent='Gotowa offline.'},onError:toast});

function updateCalendarStatus(){document.querySelectorAll('[data-calendar-status]').forEach(el=>el.textContent=googleCalendar.status);const button=$('#google-connect');if(button){button.disabled=googleCalendar.working;button.textContent=loginIdentity.guest?'Zaloguj, aby połączyć kalendarz':googleCalendar.authorized?'Synchronizuj teraz':'Połącz z Google'}document.querySelectorAll('#calendar-options input, #calendar-options button, #account-logout, #legacy-import').forEach(el=>el.disabled=googleCalendar.working);const disconnect=$('#google-disconnect');if(disconnect)disconnect.disabled=googleCalendar.working;}
function calendarSettings(){const g=googleCalendar;return `<section class="card"><h2>Kalendarz Google</h2><p>Zaakceptowane zadania trafią do osobnego kalendarza „Marketing sklepu”. Odhaczenie usuwa wydarzenie, a cofnięcie odhaczenia przywraca je.</p><p data-calendar-status role="status">${esc(g.status)}</p><form id="calendar-options"><div class="grid"><label>Wywieszenie / druk<input name="putTime" type="time" required value="${esc(g.data.putTime)}"></label><label>Zdjęcie materiału<input name="removeTime" type="time" required value="${esc(g.data.removeTime)}"></label></div><label><input type="checkbox" name="alarm" ${g.data.alarm?'checked':''}> Przypomnienie o godzinie zadania</label><button type="submit">Zapisz godziny</button></form><div class="row"><button id="google-connect" class="primary">${g.authorized?'Synchronizuj teraz':'Połącz z Google'}</button><button id="google-disconnect">Wstrzymaj synchronizację</button></div><p class="hint">Godziny według czasu w Polsce. Zdjęcie materiału jest zaplanowane na dzień wskazany w planie (automatycznie: dzień po końcu ekspozycji).</p><p class="hint">Synchronizacja działa, gdy aplikacja jest otwarta, masz internet i aktywne połączenie Google. Po ponownym otwarciu lub wygaśnięciu połączenia kliknij „Połącz z Google”. Do tego czasu przypomnienia w kalendarzu mogą nadal działać.</p><p class="hint">Do Twojego Google wysyłane są tytuły, daty i opisy zadań. PDF zostaje na telefonie. Nie zbieramy numerów sklepów ani statystyk. Wstrzymanie synchronizacji pozostawia wpisy w kalendarzu. Zmiany wykonuj w tej aplikacji — nie są pobierane z kalendarza.</p></section>`}
function bindCalendarSettings(){
 $('#google-connect').onclick=()=>googleCalendar.connect();
 $('#google-disconnect').onclick=()=>{googleCalendar.pause();updateCalendarStatus()};
 $('#calendar-options').onsubmit=async e=>{e.preventDefault();const f=new FormData(e.target);googleCalendar.data.putTime=f.get('putTime');googleCalendar.data.removeTime=f.get('removeTime');googleCalendar.data.alarm=f.has('alarm');await googleCalendar.persist();delete e.target.dataset.updateDirty;googleCalendar.schedule();toast('Godziny zapisane.')};
 googleCalendar.prepare().catch(()=>{});updateCalendarStatus();
}

function accountSettings(){if(loginIdentity.guest)return `<section class="card"><h2>Korzystasz bez logowania</h2><p>PDF-y i zadania są zapisane na tym telefonie. Możesz używać aplikacji offline.</p><button id="account-logout">Zaloguj przez Google</button><p class="hint">Konto jest opcjonalne i potrzebne tylko do kalendarza. Po zalogowaniu możesz przenieść swoje dotychczasowe materiały do konta.</p></section>`;return `<section class="card"><h2>Twoje konto</h2><p>${esc(loginIdentity.email)}</p><p class="hint">Konto zapamiętane na tym telefonie. Materiały każdego konta są przechowywane oddzielnie.</p><div class="row"><button id="account-logout">Wyloguj / zmień konto</button><button id="legacy-import">Przenieś materiały z trybu bez logowania</button></div></section>`}
function bindAccountSettings(){
 $('#account-logout').onclick=()=>{if(loginIdentity.guest){signOut();return}if(googleCalendar.working)return toast('Poczekaj na zakończenie synchronizacji.');if(confirm('Wylogować z aplikacji? Materiały pozostaną zapisane dla tego konta. Wydarzenia w Google nie zostaną usunięte.'))signOut()};
 $('#legacy-import')?.addEventListener('click',migrateLegacy);
}
async function migrateLegacyWork(){
 if(googleCalendar.working)return toast('Poczekaj na zakończenie synchronizacji.');
 if(!confirm('Skopiować materiały z trybu bez logowania do obecnego konta Google? Źródłowe dane zostaną zachowane.'))return;
 let old;
 try{
  old=await new Promise((resolve,reject)=>{const r=indexedDB.open('marketing-sklepu',1);r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)});
  if(!old.objectStoreNames.contains('data'))return toast('Brak materiałów w trybie bez logowania.');
  const read=key=>new Promise((resolve,reject)=>{const r=old.transaction('data').objectStore('data').get(key);r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)});
  const previous=await read('state');if(!previous?.docs?.length)return toast('Brak materiałów w trybie bez logowania.');
  const merged=structuredClone(state),pdfs=[];
  for(const doc of previous.docs){if(merged.docs.some(d=>d.id===doc.id))continue;const bytes=await read('pdf:'+doc.id);if(!bytes)throw Error('Brakuje pliku PDF: '+doc.name);merged.docs.push(doc);pdfs.push([doc.id,bytes])}
  if(!state.docs.length&&previous.profile)merged.profile=structuredClone(previous.profile);
  delete merged.profile.storeNumber;delete merged.profile.lastReportedDay;
  const tx=db.transaction('data','readwrite'),store=tx.objectStore('data');store.put(merged,'state');for(const [id,bytes]of pdfs)store.put(bytes,'pdf:'+id);
  await new Promise((resolve,reject)=>{tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error)});state=merged;
  const oldCalendar=await read('google-calendar');const key=googleCalendar.accountKey;
  if(oldCalendar?.accounts?.[key]&&!googleCalendar.data.accounts[key]?.calendarId){googleCalendar.data.accounts[key]=oldCalendar.accounts[key];await googleCalendar.persist()}
  googleCalendar.schedule();render();toast('Przeniesiono materiały. Sprawdź Plan i ustawienia profilu.');
 }catch(e){toast('Nie udało się przenieść danych: '+e.message)}finally{old?.close()}
}

async function importPDF(...args){updateJobs++;try{return await importPDFWork(...args)}finally{updateJobs--}}

async function exportBackup(...args){updateJobs++;try{return await exportBackupWork(...args)}finally{updateJobs--}}

async function restoreBackup(...args){updateJobs++;try{return await restoreBackupWork(...args)}finally{updateJobs--}}

async function migrateLegacy(...args){updateJobs++;try{return await migrateLegacyWork(...args)}finally{updateJobs--}}
